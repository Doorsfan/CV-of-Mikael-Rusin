/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task1;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;


/**
 *
 * @author Micke
 */

public class Controller implements Initializable {
    
    ObservableList<Person> searchList = FXCollections.observableArrayList();
    ObservableList<Job> searchJobList = FXCollections.observableArrayList();
    
    public static ArrayList<Job> holder = new ArrayList<Job>();
    
    @FXML
    private TableView<Person> peopleColumn;
    
    
    
    @FXML
    private TableView<Job> jobColumn;
    
    @FXML
    private TableColumn<Person, String> nameColumn; 
    
    @FXML
    private TableColumn<Person, Integer> idPersonColumn;
    
    @FXML
    private TableColumn<Job, Integer> idJobColumn;
    
    @FXML
    private TableColumn<Job, String> jobNameColumn;
    
    @FXML
    private TextField searchName;
    
    @FXML
    private TextField searchJob;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        peopleColumn.setItems(searchList);

        nameColumn.setCellValueFactory(new PropertyValueFactory<Person, String>("Name"));
        jobNameColumn.setCellValueFactory(new PropertyValueFactory<Job, String>("Name"));
        
        idPersonColumn.setCellValueFactory(new PropertyValueFactory<Person, Integer>("id"));
        idJobColumn.setCellValueFactory(new PropertyValueFactory<Job, Integer>("Id"));
        
        
        
        searchName.textProperty().addListener((observable, oldValue, newValue) -> {
            if(newValue.length() > 0){
                searchList.clear();
                for(Person p : Task1.Inlämning1.peopleList){
                    if(p.getName().contains(newValue)){
                        searchList.add(p);
                    }
                }

                peopleColumn.setItems(searchList);
            }
            else{
                peopleColumn.setItems(Task1.Inlämning1.peopleList);
            }
        });
        
        searchJob.textProperty().addListener((observable, oldValue, newValue) -> {
            
           if(newValue.length() > 0 && !(peopleColumn.getSelectionModel().getSelectedIndex() == -1) && Task1.Inlämning1.peopleList.size() > 0){
               searchJobList.clear();
               for(Job jobs : (peopleColumn.getSelectionModel().getSelectedItem().getJobs())){
                   if(jobs.getName().contains(searchJob.getText())){
                       searchJobList.add(jobs);
                   }
               }
               jobColumn.setItems(searchJobList);  
           }
           else{
               searchJobList.clear();
               if(Task1.Inlämning1.peopleList.size() > 0 && peopleColumn.getSelectionModel().getSelectedIndex() > -1){
                   for(Job jobs : (peopleColumn.getSelectionModel().getSelectedItem().getJobs())){
                      searchJobList.add(jobs);
                   }
                   jobColumn.setItems(searchJobList);
               }
           }
        });
    }
    
    @FXML
    private Button createPersonButton;
    
    @FXML
    private Button callServer;
    
    public static String updateName;
    
    public static String updateJob;
    
    
    @FXML
    private void addPerson(ActionEvent event) throws IOException {
        
        Stage stage;
        Parent root;
        stage = new Stage();
        root = FXMLLoader.load(getClass().getResource("PersonController.fxml"));
        stage.setScene(new Scene(root));
        stage.setTitle("Register a new person!");
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.initOwner(createPersonButton.getScene().getWindow());
        stage.showAndWait();
        
        peopleColumn.setItems(Task1.Inlämning1.peopleList);
        
    }
    
    @FXML
    private void callServer(){

        Task1.myClient.call();
    }

    
    @FXML
    private void listSelected(MouseEvent event) throws IOException{
        if (!(peopleColumn.getSelectionModel().getSelectedIndex() == -1)) {
 
            updateName = peopleColumn.getSelectionModel().getSelectedItem().getName();
            int count = 0;
            for(Person p : Task1.Inlämning1.peopleList){
                if(count == peopleColumn.getSelectionModel().getSelectedIndex()){
                    Task1.Inlämning1.jobList.clear();
                    for(Job b : p.getJobs()){
                        Task1.Inlämning1.jobList.add(b);
                    }
                }
                count += 1;
            }
            jobColumn.setItems(Task1.Inlämning1.jobList);
        }
    }
    @FXML
    private void addJob(ActionEvent event) throws IOException{
        if (!(peopleColumn.getSelectionModel().getSelectedIndex() == -1)) {
            updateName = peopleColumn.getSelectionModel().getSelectedItem().getName();
            Stage stage;
            Parent root;
            stage = new Stage();
            root = FXMLLoader.load(getClass().getResource("JobController.fxml"));
            stage.setScene(new Scene(root));
            stage.setTitle("Register a new job for a Person!");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.initOwner(createPersonButton.getScene().getWindow());
            stage.showAndWait();
            
            for(Person p : Task1.Inlämning1.peopleList){
                if(p.getName().equals(updateName)){
                    Task1.Inlämning1.jobList.clear();
                    for(Job b : p.getJobs()){
                        Task1.Inlämning1.jobList.add(b);
                    }
                }
            }

            jobColumn.setItems(Task1.Inlämning1.jobList);
        }
    }
    
    @FXML
    private void updatePerson(ActionEvent event) throws IOException{
        
        if (!(peopleColumn.getSelectionModel().getSelectedIndex() == -1)) {
            updateName = peopleColumn.getSelectionModel().getSelectedItem().getName();
            Stage stage;
            Parent root;
            stage = new Stage();
            root = FXMLLoader.load(getClass().getResource("updatePersonNameController.fxml"));
            stage.setScene(new Scene(root));
            stage.setTitle("Change a Persons Name!");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.initOwner(createPersonButton.getScene().getWindow());
            stage.showAndWait();
 
            
            peopleColumn.setItems(Task1.Inlämning1.peopleList);
             //Set the tableView to be the Observable List, fuck their shitty ass fucking shit names
             //set peopleColumn to be the peopleList
            
        }
        
    }
    
    @FXML
    private void updateJob(ActionEvent event) throws IOException{
        if(!(jobColumn.getSelectionModel().getSelectedIndex() == -1)){
            updateJob = jobColumn.getSelectionModel().getSelectedItem().getName();
            Stage stage;
            Parent root;
            stage = new Stage();
            root = FXMLLoader.load(getClass().getResource("updateJobNameController.fxml"));
            stage.setScene(new Scene(root));
            stage.setTitle("Change a Jobs Name!");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.initOwner(createPersonButton.getScene().getWindow());
            stage.showAndWait();
 
            
            jobColumn.setItems(Task1.Inlämning1.jobList);
        }
    }
    

    

    public static int ChosenIndex = 0;
    @FXML
    public void removePerson(ActionEvent event) throws IOException{
        if (!(peopleColumn.getSelectionModel().getSelectedIndex() == -1)) {
            int index = peopleColumn.getSelectionModel().getSelectedIndex();
            
            Task1.Inlämning1.jobList.clear();
            Task1.Inlämning1.peopleList.remove(peopleColumn.getSelectionModel().getSelectedItem());
            peopleColumn.setItems(Task1.Inlämning1.peopleList);
            if(Task1.Inlämning1.peopleList.size() > 0){
                int count = 0;
                for(Person p : Task1.Inlämning1.peopleList){
                    if(count == index-1 || count == index){
                        peopleColumn.getSelectionModel().select(p);
                        ArrayList<Job> jobs = p.getJobs();
                        for(Job b : jobs){
                            Task1.Inlämning1.jobList.add(b);
                        }
                        jobColumn.setItems(Task1.Inlämning1.jobList);
                        break;
                        
                    }
                    count += 1;
                }             
            }
        }
    }
    
    @FXML
    public void removeJob(ActionEvent event) throws IOException{
        if(!(jobColumn.getSelectionModel().getSelectedIndex() == -1)){
            Job toRemove = jobColumn.getSelectionModel().getSelectedItem();
            Task1.Inlämning1.jobList.remove(jobColumn.getSelectionModel().getSelectedItem());
            for(Person p: Task1.Inlämning1.peopleList){
                if(updateName.equals(p.getName())){
                    p.removeJob(toRemove);
                }
            }
            jobColumn.setItems(Task1.Inlämning1.jobList);
        }
    }
    
    
}
