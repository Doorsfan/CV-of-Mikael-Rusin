/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task1;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class SimpleObject {
    
    //For sake of JAXB converstion to xml, we need a empty constructor
    public SimpleObject(){
        
    }
    
    public SimpleObject(int id, String name){
        super();
        this.id = id;
        this.name = name;
    }
    
    private int id;
    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
