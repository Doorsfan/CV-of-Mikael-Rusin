/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author Micke
 */
public class updatePersonController implements Initializable {
    
    @FXML
    private Button backButton;
    
    @FXML
    private Text personName;
    
    @FXML
    private TextField newName;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        personName.setText("Change name of: " + Task1.Controller.updateName);
    }
    
    @FXML
    private void handlecancel(ActionEvent event) throws IOException {
        Stage stage = (Stage) backButton.getScene().getWindow();

        stage.close();
    }
    
    
    
    @FXML
    private void handleUpdate(ActionEvent event) throws IOException {
        if(newName.getText().length() > 0){
            for(Person p : Task1.Inlämning1.peopleList){
                if(p.getName().equals(Task1.Controller.updateName)){
                    Person old = p;
                    Person newPerson = new Person(1,newName.getText(), old.getJobs());
                    Task1.Inlämning1.peopleList.remove(p);
                    Task1.Inlämning1.peopleList.add(newPerson);
                    break;
                }
            }
            Stage stage = (Stage) backButton.getScene().getWindow();

            stage.close();
        }
        else{
            System.err.println("You cannot change a name to a empty name!");
        }
        
        
        
    }
}
