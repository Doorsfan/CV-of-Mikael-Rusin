/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task1;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

/**
 *
 * @author Micke
 */

@ApplicationScoped
@ManagedBean
public class myClient {
    public static void call(){
        Client client = ClientBuilder.newClient();
        SimpleObject reuslt = client.target("localhost:8080/resources/MyRestService/object").request().get(SimpleObject.class);
        
        
    }
    
}
