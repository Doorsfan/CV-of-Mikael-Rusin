/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task1;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author Micke
 */

public class addPersonController implements Initializable {
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }
    
    @FXML
    private Button backButton;
    
    @FXML
    private Button addPersonButton;
    
    @FXML
    private TextField addField;
            
    @FXML
    private void handlecancel(ActionEvent event) throws IOException {
        Stage stage = (Stage) backButton.getScene().getWindow();

        stage.close();
    }
    @FXML
    private void registerPerson(ActionEvent event) throws IOException {
        if(addField.getText().length() == 0){
            System.out.println("You cannot add a Customer with no name.");
        }
        
        else{
            ArrayList<Job> jobs = new ArrayList<Job>();
            try{
                int highest = 0;
                for(Person p : Task1.Inlämning1.people){
                    if(p.getName().equals(addField.getText())){
                        System.err.println("You cannot add a person with the same name again!");
                        return;
                    }
                    if(highest < p.getId()){
                        highest = p.getId();
                    }
                    
                }
                highest += 1;
                
                Person toAdd = new Person(highest,addField.getText(), jobs);
                Task1.Inlämning1.people.add(toAdd);
                Task1.Inlämning1.peopleList.add(toAdd);

                Stage stage = (Stage) backButton.getScene().getWindow();
                stage.close();
                

            } catch(Exception e){
                
                System.out.println(e);
            }
        }
    }
    
}