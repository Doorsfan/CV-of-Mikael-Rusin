/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task1;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Micke
 */
public class Person implements Serializable{
    private int id;
    private String name;
    private ArrayList<Job> jobs = new ArrayList<Job>();
    public Person(String name){
        this.name = name;
    }
    
    public void setJobs(ArrayList<Job> jobs){
        this.jobs = jobs;
    }
    
    public void setName(String name){
        this.name = name;
    }
    
    public String getName(){
        return this.name;
    }
    
    public void setId(int id){
        this.id = id;
    }
    
    public int getId(){
        return this.id;
    }
    
    public ArrayList<Job> getJobs(){
        if(this.jobs != null){
            return this.jobs;
        }
        else{
            return new ArrayList<Job>();
        }
    }
    
    public void addJob(Job job){
        this.jobs.add(job);
    }
    
    public void removeJob(Job job){
        this.jobs.remove(job);
    }
}
