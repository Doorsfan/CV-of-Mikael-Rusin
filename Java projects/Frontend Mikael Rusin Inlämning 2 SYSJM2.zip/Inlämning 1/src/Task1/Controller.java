/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task1;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

import javax.ws.rs.*;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.client.Entity;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.codehaus.jackson.map.ObjectMapper;




/**
 *
 * @author Micke
 */

public class Controller implements Initializable {
    
    
    
    Client client = ClientBuilder.newClient();
    
    ObservableList<Person> searchList = FXCollections.observableArrayList();
    ObservableList<Job> searchJobList = FXCollections.observableArrayList();
    
    public static ArrayList<Job> holder = new ArrayList<Job>();
    
    @FXML
    private TableView<Person> peopleColumn;
    
    
    
    @FXML
    private TableView<Job> jobColumn;
    
    @FXML
    private TableColumn<Person, String> nameColumn; 
    
    @FXML
    private TableColumn<Person, Integer> idPersonColumn;
    
    @FXML
    private TableColumn<Job, Integer> idJobColumn;
    
    @FXML
    private TableColumn<Job, String> jobNameColumn;
    
    @FXML
    private TextField searchName;
    
    @FXML
    private TextField searchJob;
    
    @FXML
    private Button createPersonServer;
    
    @FXML
    private Button updatePersonServer;
    
    @FXML
    private Button deletePersonServer;
    
    @FXML
    private Button createJobServer;
    
    @FXML
    private Button updateJobServer;
    
    @FXML
    private Button deleteJobServer;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        peopleColumn.setItems(searchList);

        nameColumn.setCellValueFactory(new PropertyValueFactory<Person, String>("Name"));
        jobNameColumn.setCellValueFactory(new PropertyValueFactory<Job, String>("Name"));
        
        
        searchName.textProperty().addListener((observable, oldValue, newValue) -> {
            if(newValue.length() > 0){
                searchList.clear();
                for(Person p : Task1.Inlämning1.peopleList){
                    if(p.getName().contains(newValue)){
                        searchList.add(p);
                    }
                }

                peopleColumn.setItems(searchList);
            }
            else{
                peopleColumn.setItems(Task1.Inlämning1.peopleList);
            }
        });
        
        searchJob.textProperty().addListener((observable, oldValue, newValue) -> {
            
           if(newValue.length() > 0 && !(peopleColumn.getSelectionModel().getSelectedIndex() == -1) && Task1.Inlämning1.peopleList.size() > 0){
               searchJobList.clear();
               for(Job jobs : (peopleColumn.getSelectionModel().getSelectedItem().getJobs())){
                   if(jobs.getName().contains(searchJob.getText())){
                       searchJobList.add(jobs);
                   }
               }
               jobColumn.setItems(searchJobList);  
           }
           else{
               searchJobList.clear();
               if(Task1.Inlämning1.peopleList.size() > 0 && peopleColumn.getSelectionModel().getSelectedIndex() > -1){
                   for(Job jobs : (peopleColumn.getSelectionModel().getSelectedItem().getJobs())){
                      searchJobList.add(jobs);
                   }
                   jobColumn.setItems(searchJobList);
               }
           }
        });
    }
    
    @FXML
    private Button createPersonButton;
    
    @FXML
    private Button callServer;
    
    public static String updateName;
    
    public static String updateJob;
    
    
    @FXML
    private void addPerson(ActionEvent event) throws IOException {
        
        Stage stage;
        Parent root;
        stage = new Stage();
        root = FXMLLoader.load(getClass().getResource("PersonController.fxml"));
        stage.setScene(new Scene(root));
        stage.setTitle("Register a new person!");
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.initOwner(createPersonButton.getScene().getWindow());
        stage.showAndWait();
        
        peopleColumn.setItems(Task1.Inlämning1.peopleList);
        
    }
    
 

    
    @FXML
    private void listSelected(MouseEvent event) throws IOException{
        if (!(peopleColumn.getSelectionModel().getSelectedIndex() == -1)) {
 
            updateName = peopleColumn.getSelectionModel().getSelectedItem().getName();
            int count = 0;
            for(Person p : Task1.Inlämning1.peopleList){
                if(count == peopleColumn.getSelectionModel().getSelectedIndex()){
                    Task1.Inlämning1.jobList.clear();
                    for(Job b : p.getJobs()){
                        Task1.Inlämning1.jobList.add(b);
                    }
                }
                count += 1;
            }
            jobColumn.setItems(Task1.Inlämning1.jobList);
        }
    }
    
    @FXML
    private void createJobOnServer(ActionEvent event) throws IOException{
                Stage stage;
                Parent root;
                stage = new Stage();
                root = FXMLLoader.load(getClass().getResource("createJobOnServerController.fxml"));
                stage.setScene(new Scene(root));
                stage.setTitle("Register a new job for a Person!");
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.initOwner(createPersonButton.getScene().getWindow());
                stage.showAndWait();

    }
    
    @FXML
    private void deleteJobOnServer(ActionEvent event) throws IOException{
                Stage stage;
                Parent root;
                stage = new Stage();
                root = FXMLLoader.load(getClass().getResource("removeJobOnServerController.fxml"));
                stage.setScene(new Scene(root));
                stage.setTitle("Register a new job for a Person!");
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.initOwner(createPersonButton.getScene().getWindow());
                stage.showAndWait();

    }
    
    @FXML
    private void updateJobOnServer(ActionEvent event) throws IOException{
                Stage stage;
                Parent root;
                stage = new Stage();
                root = FXMLLoader.load(getClass().getResource("updateJobOnServerController.fxml"));
                stage.setScene(new Scene(root));
                stage.setTitle("Register a new job for a Person!");
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.initOwner(createPersonButton.getScene().getWindow());
                stage.showAndWait();

    }
    
    @FXML
    private void getJobOnServer(ActionEvent event) throws IOException{
                Stage stage;
                Parent root;
                stage = new Stage();
                root = FXMLLoader.load(getClass().getResource("getJobOnServerController.fxml"));
                stage.setScene(new Scene(root));
                stage.setTitle("Register a new job for a Person!");
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.initOwner(createPersonButton.getScene().getWindow());
                stage.showAndWait();

    }
    
    @FXML
    private void createPersonOnServer(ActionEvent event) throws IOException{
                Stage stage;
                Parent root;
                stage = new Stage();
                
                
                
                root = FXMLLoader.load(getClass().getResource("createPersonOnServerController.fxml"));
                stage.setScene(new Scene(root));
                stage.setTitle("Register a new job for a Person!");
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.initOwner(createPersonButton.getScene().getWindow());
                stage.showAndWait();

    }
    
    @FXML
    private void deletePersonOnServer(ActionEvent event) throws IOException{
                Stage stage;
                Parent root;
                stage = new Stage();
                root = FXMLLoader.load(getClass().getResource("removePersonOnServerController.fxml"));
                stage.setScene(new Scene(root));
                stage.setTitle("Register a new job for a Person!");
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.initOwner(createPersonButton.getScene().getWindow());
                stage.showAndWait();

    }
    
    @FXML
    private void updatePersonOnServer(ActionEvent event) throws IOException{
                
                //USE FOR UPDATING
                Person p = new Person("name");
                
                p.setName("lol");
                
                Response r = client
                            .target("http://localhost:8080/BackendDemoFootball/webapi/persons/2")
                            .request()
                            .put(Entity.entity(p, MediaType.APPLICATION_JSON));
                
                //USE FOR CREATING
                Person c = client
                       .target("http://localhost:8080/BackendDemoFootball/webapi/persons/2")
                       .request(MediaType.APPLICATION_JSON)
                       .post(Entity.json(p), Person.class);
                
                //USE FOR DELETING
                Response v = client
                        .target("http://localhost:8080/BackendDemoFootball/webapi/teams/2")
                        .request(MediaType.APPLICATION_JSON)
                        .delete();
                        
        
                Stage stage;
                Parent root;
                stage = new Stage();
                root = FXMLLoader.load(getClass().getResource("updatePersonOnServerController.fxml"));
                stage.setScene(new Scene(root));
                stage.setTitle("Register a new job for a Person!");
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.initOwner(createPersonButton.getScene().getWindow());
                stage.showAndWait();
                
                
    }
    
    public String[] parseJSON(String input){
        String parsedJSON = "";
        
        String[] splitInput = input.split(":");
        
        int firstIndex = 0;
        int secondIndex = 0;
        
        String[] jobValues; // cannot recall how to do String array atm
        boolean passedJob = false;
        
        String nameValue = "";
        for(int i = 0; i < splitInput.length; i++){
            if(splitInput[i].equals("name")){
                firstIndex = i;
            }
            if(i == firstIndex + 1){
                nameValue = splitInput[i];
            }
            
            if(splitInput[i].equals("jobs")){
                secondIndex = i;
            }
        }
        
        
        
        
        return splitInput;
    }
    
    @FXML
    private void printAllPeople(ActionEvent event) throws IOException{
        Stage stage;
        Parent Root;
        
        String persons = client.target("http://localhost:8080/BackendDemoFootball/webapi/persons")
                       .request(MediaType.APPLICATION_JSON)
                       .get(String.class);
        
        System.out.println(persons);
    
    }
    
    @FXML
    private void getPersonOnServer(ActionEvent event) throws IOException{
                Stage stage;
                Parent root;
                
                
                //{
   // "id": 2,
   // "jobs": [],
   // "name": "derpy"
  //}
    
  
                    String persons = client.target("http://localhost:8080/BackendDemoFootball/webapi/persons")
                       .request(MediaType.APPLICATION_JSON)
                       .get(String.class);
                    
                    
                    //[{"id":2,"jobs":[],"name":"derpy"}]
                   System.out.println(persons);
                   String[] fix = persons.split(",");
                   int finalId = 0;
                   for(int i = 0; i < fix.length; i++){
                       fix[i] = fix[i].replaceAll("[^a-zA-Z0-9:]", "");
                       String something = fix[i];
                       String nameOfPerson = "";
                       String jobList = "";

                       char idFirstChar = something.charAt(0);
                       char idScndChar = something.charAt(1);
                       char idThirdChar = something.charAt(2);
                       if(idFirstChar == 'i' && idScndChar == 'd' && idThirdChar == ':'){
                           String[] idSplit = something.split(":");
                           finalId = Integer.parseInt(idSplit[1]); //We need this for setting id
                           
                       }
                       String[] test = something.split(":");
                       if(test.length == 2){
                           if(test[0].equals("name")){
                               nameOfPerson = test[1];
                           }
                           if(test[0].equals("jobs")){
                               jobList = test[1];
                           }
                       }
                       
                       System.out.println("Found name of person : " + nameOfPerson + " , with id : " + finalId);
                       
                       if(nameOfPerson.length() > 0){
                           Person toAdd = new Person(nameOfPerson);
                           toAdd.setId(finalId);
                           Task1.Inlämning1.people.add(toAdd);
                           Task1.Inlämning1.peopleList.add(toAdd); //Just aquire the person, don't care about mapping in terms of Jobs, we do that in the other requests
                           peopleColumn.setItems(Task1.Inlämning1.peopleList);
                       }
                        
                   }
                   

    }
    
    
    
    @FXML
    private void addJob(ActionEvent event) throws IOException{
        if (!(peopleColumn.getSelectionModel().getSelectedIndex() == -1)) {
            updateName = peopleColumn.getSelectionModel().getSelectedItem().getName();
            Stage stage;
            Parent root;
            stage = new Stage();
            root = FXMLLoader.load(getClass().getResource("JobController.fxml"));
            stage.setScene(new Scene(root));
            stage.setTitle("Register a new job for a Person!");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.initOwner(createPersonButton.getScene().getWindow());
            stage.showAndWait();
            
            for(Person p : Task1.Inlämning1.peopleList){
                if(p.getName().equals(updateName)){
                    Task1.Inlämning1.jobList.clear();
                    for(Job b : p.getJobs()){
                        Task1.Inlämning1.jobList.add(b);
                    }
                }
            }

            jobColumn.setItems(Task1.Inlämning1.jobList);
        }
    }
    
    @FXML
    private void updatePerson(ActionEvent event) throws IOException{
        
        if (!(peopleColumn.getSelectionModel().getSelectedIndex() == -1)) {
            updateName = peopleColumn.getSelectionModel().getSelectedItem().getName();
            Stage stage;
            Parent root;
            stage = new Stage();
            root = FXMLLoader.load(getClass().getResource("updatePersonNameController.fxml"));
            stage.setScene(new Scene(root));
            stage.setTitle("Change a Persons Name!");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.initOwner(createPersonButton.getScene().getWindow());
            stage.showAndWait();
 
            
            peopleColumn.setItems(Task1.Inlämning1.peopleList);
             //Set the tableView to be the Observable List, fuck their shitty ass fucking shit names
             //set peopleColumn to be the peopleList
            
        }
        
    }
    
    @FXML
    private void updateJob(ActionEvent event) throws IOException{
        if(!(jobColumn.getSelectionModel().getSelectedIndex() == -1)){
            updateJob = jobColumn.getSelectionModel().getSelectedItem().getName();
            Stage stage;
            Parent root;
            stage = new Stage();
            root = FXMLLoader.load(getClass().getResource("updateJobNameController.fxml"));
            stage.setScene(new Scene(root));
            stage.setTitle("Change a Jobs Name!");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.initOwner(createPersonButton.getScene().getWindow());
            stage.showAndWait();
 
            
            jobColumn.setItems(Task1.Inlämning1.jobList);
        }
    }
    

    

    public static int ChosenIndex = 0;
    @FXML
    public void removePerson(ActionEvent event) throws IOException{
        if (!(peopleColumn.getSelectionModel().getSelectedIndex() == -1)) {
            int index = peopleColumn.getSelectionModel().getSelectedIndex();
            
            Task1.Inlämning1.jobList.clear();
            Task1.Inlämning1.peopleList.remove(peopleColumn.getSelectionModel().getSelectedItem());
            peopleColumn.setItems(Task1.Inlämning1.peopleList);
            if(Task1.Inlämning1.peopleList.size() > 0){
                int count = 0;
                for(Person p : Task1.Inlämning1.peopleList){
                    if(count == index-1 || count == index){
                        peopleColumn.getSelectionModel().select(p);
                        ArrayList<Job> jobs = p.getJobs();
                        for(Job b : jobs){
                            Task1.Inlämning1.jobList.add(b);
                        }
                        jobColumn.setItems(Task1.Inlämning1.jobList);
                        break;
                        
                    }
                    count += 1;
                }             
            }
        }
    }
    
    @FXML
    public void removeJob(ActionEvent event) throws IOException{
        if(!(jobColumn.getSelectionModel().getSelectedIndex() == -1)){
            Job toRemove = jobColumn.getSelectionModel().getSelectedItem();
            Task1.Inlämning1.jobList.remove(jobColumn.getSelectionModel().getSelectedItem());
            for(Person p: Task1.Inlämning1.peopleList){
                if(updateName.equals(p.getName())){
                    p.removeJob(toRemove);
                }
            }
            jobColumn.setItems(Task1.Inlämning1.jobList);
        }
    }
    
    
}
