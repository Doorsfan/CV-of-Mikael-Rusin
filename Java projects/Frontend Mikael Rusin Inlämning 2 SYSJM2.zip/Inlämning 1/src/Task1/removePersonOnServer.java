/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task1;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javafx.event.ActionEvent;
import javax.ws.rs.core.Response;

/**
 *
 * @author User
 */
public class removePersonOnServer implements Initializable {
    
    @FXML
    private Button UpdatePerson;
    
    @FXML
    private TextField NewName;
    
    @FXML
    private TextField idOfPerson;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }
    
    
    @FXML
    private void TriggerDelete(ActionEvent event){
        int id = Integer.parseInt(idOfPerson.getText());
        String strId = Integer.toString(id);
        
        Client client = ClientBuilder.newClient();
        
        
        Response v = client
                        .target("http://localhost:8080/BackendDemoFootball/webapi/persons/" + strId)
                        .request(MediaType.APPLICATION_JSON)
                        .delete();
        
    }
    
    
    
}
