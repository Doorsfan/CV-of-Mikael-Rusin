/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author Micke
 */
public class addJobController implements Initializable {
    
    @FXML
    private Button backButton;
    
    @FXML
    private Text jobText;
    
    @FXML
    private Button addJobButton;
    
    @FXML
    private TextField addField;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        jobText.setText("Create a new job for: " + Task1.Controller.updateName);
    }
    
    @FXML
    private void handlecancel(ActionEvent event) throws IOException {
        Stage stage = (Stage) backButton.getScene().getWindow();

        stage.close();
    }
    
    @FXML
    private void addJob (ActionEvent event) throws IOException{
        if(addField.getText().length() == 0){
            System.out.println("You cannot add a Job with no name.");
        }
        else{
            Person toUpdate = null;
            int jobId = 0;
            for(Person p : Task1.Inlämning1.peopleList){
                if(p.getName().equals(Task1.Controller.updateName)){
                    toUpdate = p;
                }
                
                for(Job j : p.getJobs()){
                    if(jobId < j.getId()){
                        jobId = j.getId();
                    }
                    
                }
            }
            jobId += 1;
            
            
            Job newJob = new Job(addField.getText());
            toUpdate.addJob(newJob);
            
            Stage stage = (Stage) backButton.getScene().getWindow();

            stage.close();
        }
        
        
    }
}
