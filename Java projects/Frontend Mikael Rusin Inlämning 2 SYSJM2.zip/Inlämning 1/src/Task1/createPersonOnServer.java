/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task1;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author User
 */
public class createPersonOnServer {
    
    @FXML
    private TextField NewName;
    
    @FXML
    private Button createPerson;
    
    
    
    
    @FXML
    private void TriggerCreate(){
        String name = NewName.getText();
        
    Person newPerson = new Person(name);
                
    
                
    Client client = ClientBuilder.newClient();
    
    Person c = client
            .target("http://localhost:8080/BackendDemoFootball/webapi/persons")
            .request(MediaType.APPLICATION_JSON)
            .post(Entity.json(newPerson), Person.class);
    }
    
    
}
