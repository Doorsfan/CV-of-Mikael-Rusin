/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task1;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author Micke
 */
public class updateJobName implements Initializable {
    
    @FXML
    private Button backButton;
    
    @FXML
    private Text jobText;
    
    @FXML
    private TextField newJobText;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        jobText.setText("Change name of the following job: " + Task1.Controller.updateJob);
    }
    
    @FXML
    private void handlecancel(ActionEvent event) throws IOException {
        Stage stage = (Stage) backButton.getScene().getWindow();

        stage.close();
    }
    
    @FXML
    private void changeJob(ActionEvent event) throws IOException {
        if(newJobText.getText().length() > 0){
            for(Person p : Task1.Inlämning1.peopleList){
                if(p.getName().equals(Task1.Controller.updateName)){
                    for(Job b : Task1.Inlämning1.jobList){
                        Job old = b;
                        Job newJob = new Job(newJobText.getText());
                        Task1.Inlämning1.jobList.remove(old);
                        Task1.Inlämning1.jobList.add(newJob);
                        ArrayList<Job> oldOnes = p.getJobs();
                        oldOnes.remove(b);
                        oldOnes.add(newJob);
                        p.setJobs(oldOnes);
                        break;
                        
                    }
                }
            }
            Stage stage = (Stage) backButton.getScene().getWindow();

            stage.close();
        }
        
    }
}
