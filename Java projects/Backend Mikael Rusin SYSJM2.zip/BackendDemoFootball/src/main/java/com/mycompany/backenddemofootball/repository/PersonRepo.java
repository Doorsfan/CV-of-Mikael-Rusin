package com.mycompany.backenddemofootball.repository;

import com.mycompany.backenddemofootball.models.Job;
import com.mycompany.backenddemofootball.models.Person;
import java.util.ArrayList;
import java.util.List;

public class PersonRepo {
    private static PersonRepo fakeDBinstance;
    private List<Person> people; 
    
    private PersonRepo() {
        people = new ArrayList();
        people.add(new Person(1, "Barcelona"));
        people.add(new Person(2, "Arsenal"));
        people.add(new Person(3, "Malmö FF"));
        
        List<Job> jobs = new ArrayList();
        jobs.add(new Job(1, "Messi"));
        jobs.add(new Job(2, "Xavi"));
        
        people.get(0).setJobs(jobs);
    }
    
    public static PersonRepo getInstance() {
        if(fakeDBinstance == null) {
            fakeDBinstance = new PersonRepo();
        }
        return fakeDBinstance;
    }

    public List<Person> getPersons() {
        return people;
    }
}
