package com.mycompany.backenddemofootball.repository;

import com.mycompany.backenddemofootball.models.Job;
import com.mycompany.backenddemofootball.models.Person;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Session;

public class PersonRepository {
    
    public List<Person> getPersons() {
        Session session = NewHibernateUtil.getSession();
        session.beginTransaction();
        List<Person> persons = session.createCriteria(Person.class).list();
        
        
        for(Person t : persons) {
            t.getJobs().size();
        }
        //session.close();
        return persons;
    }

    public Person getPerson(int personId) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        Person person = (Person) session.get(Person.class, personId);
        person.getJobs().size();
        session.close();
        return person;
    }
    
    public void addPerson(Person person) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.save(person);
        session.getTransaction().commit();
        session.close();
    }

    public void updatePerson(Person updatedPerson) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.update(updatedPerson);
        session.getTransaction().commit();
        session.close();
    }

    public void removePerson(int id) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Person persistentInstance = (Person) session.load(Person.class, id);
        session.delete(persistentInstance);
        session.getTransaction().commit();
        session.close();
    }

    public void addJob(Person person, Job newJob) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        newJob.setPerson(person);
        session.save(newJob);
        session.getTransaction().commit();
        session.close();
    }

    public Job getJob(int jobId) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        Job Job = (Job) session.get(Job.class, jobId);
        session.close();
        return Job;
    }

    public void updateJob(Job job) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.update(job);
        session.getTransaction().commit();
        session.close();
    }

    public void deleteJob(int jobId) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Job jobToDelete = (Job) session.load(Job.class, jobId);
        session.delete(jobToDelete);
        session.getTransaction().commit();
        session.close();
    }
}   
