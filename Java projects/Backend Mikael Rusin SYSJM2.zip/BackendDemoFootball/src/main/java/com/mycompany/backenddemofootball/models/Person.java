package com.mycompany.backenddemofootball.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

//Team är Person
@Entity
public class Person implements Serializable {
    
    @Id@GeneratedValue
    private int id;
    private String name;
    @OneToMany(mappedBy="person", cascade = CascadeType.REMOVE)
    @JsonBackReference
    private List<Job> Jobs = new ArrayList();

    public Person() {}

    public Person(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Job> getJobs() {
        return Jobs;
    }

    public void setJobs(List<Job> Jobs) {
        this.Jobs = Jobs;
    }
    
    public void addJob(Job Job) {
        Jobs.add(Job);
    }

    public Job getJob(int JobId) {
        Job JobToGet = null;
        for(Job p : Jobs) {
            if(p.getId() == JobId) {
                JobToGet = p;
                break;
            }
        }
        return JobToGet;
    }

    public void updateJob(int JobId, Job Job) {
        for(int i = 0; i < Jobs.size(); i++) {
            if(Jobs.get(i).getId() == JobId) {
                Jobs.set(i, Job);
                break;
            }
        }
    }

    public void deleteJob(int JobId) {
        for(Job p : Jobs) {
            if(p.getId() == JobId) {
                Jobs.remove(p);
                break;
            }
        }
    }
}
