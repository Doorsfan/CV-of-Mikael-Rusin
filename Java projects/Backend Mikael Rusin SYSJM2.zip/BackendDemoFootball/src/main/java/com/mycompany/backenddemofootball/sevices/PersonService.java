/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.backenddemofootball.sevices;

import com.mycompany.backenddemofootball.models.Person;
import com.mycompany.backenddemofootball.repository.PersonRepository;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Christoffer
 */
public class PersonService {
    PersonRepository PersonDB;
    
    public PersonService() {
        PersonDB = new PersonRepository();
    }
            
    public List<Person> getPersons() {
        return PersonDB.getPersons();
    }
    
    public Person getPerson(int id) {
        return PersonDB.getPerson(id);
    }

    public void addPerson(Person Person) {
        PersonDB.addPerson(Person);
    }

    public Person updatePerson(Person Person) {
        PersonDB.updatePerson(Person);
        return Person;
    }

    public void removePerson(int id) {
        PersonDB.removePerson(id);
    }
}
