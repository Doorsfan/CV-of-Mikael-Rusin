package com.mycompany.backenddemofootball.resource;

import com.mycompany.backenddemofootball.models.Job;
import com.mycompany.backenddemofootball.sevices.JobService;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/Jobs")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class JobResource {
    
    JobService JobService = new JobService();
    
    @GET
    @Path("/Jobs/{PersonId}")
    public List<Job> getJobs(@PathParam("PersonId") int id) {
        return JobService.getJobs(id);
    }
    
    @GET
    @Path("/{JobId}")
    public Job getJob(@PathParam("JobId") int JobId) {
        return JobService.getJob(JobId);
    }
    
    @POST
    public void addJobs(@PathParam("PersonId") int PersonId, Job Job) {
        JobService.addJob(PersonId, Job);
    }
    
    @PUT
    @Path("/{JobId}")
    public void updateJob(@PathParam("PersonId") int PersonId, @PathParam("JobId") int JobId, Job Job) {
        JobService.updateJob(PersonId, JobId, Job);
    }
    
    @DELETE
    @Path("/{JobId}")
    public void deleteJob(@PathParam("JobId") int JobId) {
        JobService.deleteJob(JobId);
    }
}
