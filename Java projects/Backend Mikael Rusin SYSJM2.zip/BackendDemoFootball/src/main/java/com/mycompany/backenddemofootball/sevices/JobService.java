/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.backenddemofootball.sevices;

import com.mycompany.backenddemofootball.models.Job;
import com.mycompany.backenddemofootball.models.Person;
import com.mycompany.backenddemofootball.repository.PersonRepository;
import java.util.List;

/**
 *
 * @author Christoffer
 */
public class JobService {
    
    //Nu är dock denna klass beroende av klasserna nedan, detta vill man 
    //helst undvika i Java
    PersonService PersonService;
    
    PersonRepository PersonDB;
    
    public JobService() {
        PersonService = new PersonService();
        PersonDB = new PersonRepository();
    }
    
    public List<Job> getJobs(int id) {
        return PersonDB.getPerson(id).getJobs();
    }

    public void addJob(int PersonId, Job Job) {
        Person PersonToAddJobOn = PersonDB.getPerson(PersonId);
        PersonDB.addJob(PersonToAddJobOn, Job);
    }
    
    public Job getJob(int JobId) {
        return PersonDB.getJob(JobId);
    }

    public void updateJob(int PersonId, int JobId, Job Job) {
        Person PersonToUpdateJobIn = PersonDB.getPerson(PersonId);
        Job.setId(JobId);
        Job.setPerson(PersonToUpdateJobIn);
        PersonDB.updateJob(Job);
        
    }

    public void deleteJob(int JobId) {
        PersonDB.deleteJob(JobId);
    }
}
